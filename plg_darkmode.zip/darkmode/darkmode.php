<?php

// No direct access
defined('_JEXEC') or die;

/**
 * ElisDarkmode Plugin
 *
 * @author      Elias Ritter
 * @license     GNU General Public License (GPL) 2.0 or later
 *
 * @version     1.0 | 03.2023
 * @package     ElisDarkmode Plugin
 * @since       version 1.0
 * @copyright   2023 Elias Ritter
 */

// Import Core
require(__DIR__ . '/app/core.php');